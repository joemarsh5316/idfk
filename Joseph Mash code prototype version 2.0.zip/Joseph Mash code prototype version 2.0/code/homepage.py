import tkinter as tk
# this will import the foundation code to build the user interface
from PIL import Image, ImageTk  
# this will import the ability to use images within the user interface
import customtkinter as ctk 
# this will import additional features to allow for the user interface to look more modern
import webbrowser
# this will import the ability to access links via the default browser to open up links
import hotel_booking
# this will import the hotel booking ui that can be opened with a click of the hotel button
ctk.set_default_color_theme("green")
# this will set the default theme of the app to green this will mean that the default colours for buttons etc will be green
hp_root = ctk.CTk()

class images:
    img_1 = ctk.CTkImage(Image.open(r"assets\icons\settings\settings icon.png"), size = (50,50))
    # img_1 is the setting icon that will be used to access the settings page it will be displayed on the left and will not be easy to miss
    img_2 = ctk.CTkImage(Image.open(r"assets\icons\hotel icon\hotel_no_bg_icon.png"), size = (50,50))
    # img_2 is the accomodation icon that will be used to access the settings page it will be displayed on the left and will not be easy to miss
    img_3 = ctk.CTkImage(Image.open(r"assets\animal examples\sloth.jpg"), size = (75,75))
    # img_3 is the photo for the sloths to show an example of what is displayed on the live
    img_4 = ctk.CTkImage(Image.open(r"assets\animal examples\pandas.jpg"), size = (75,75))
    # img_4 is the photo for the pandas to show an example of what is displayed on the live
    img_5 = ctk.CTkImage(Image.open(r"assets\animal examples\penguins.jpg"), size = (75,75))
    # img_5 is the photo for the penguins to show an example of what is displayed on the live
    img_6 = ctk.CTkImage(Image.open(r"assets\animal examples\giraffe.jpg"), size = (75,75))
    # img_6 is the photo for the chickens to show an example of what is displayed on the live
    img_7 = ctk.CTkImage(Image.open(r"assets\animal examples\gorilla.jpg"), size = (75,75))
    # img_7 is the photo for the gorillas to show an example of what is displayed on the live
    img_8 = ctk.CTkImage(Image.open(r"assets\animal examples\lions.jpg"), size = (75,75))
    # img_8 is the photo for the lions to show an example of what is displayed on the live
    img_9 = ctk.CTkImage(Image.open(r"assets\icons\store icon\store icon.png"), size = (50,50))



def root_maker():
    # this will form the initial app to which the user will login and be able to access their homepage
    hp_root.geometry("650x650") 
    # this will decide the apps geometry i have went with the 650x650 this is because it is a moderate size however is also able to fit on the screen 
    hp_root.title("Riget Zoo Adventures HomePage") 
    # this will change the title to display Riget Zoo Adventures
    hp_root.iconbitmap(r"assets\general assets\inverted rza logo.ico") 
    # this will change the default icon to one the will be inputted via a raw string this is so it can access the file directory
    hp_root._set_appearance_mode("dark")
    # this will change the default appearance mode to dark this is so the app can match a certain theme however this may have the possibility to be changed within the settings


    

    class frames:
        # this is the class that will show the frames and display information or button that can be pressed.
        frame_alpha = ctk.CTkFrame(master = hp_root, width = 650, height = 650, fg_color = "#242424", bg_color = "#242424")
        # this is the frame that will hold the user interface together this is incase anybody tries to break the ui and disfigure it frame alpha will keep everything to it's orignal state
        frame_1 = ctk.CTkScrollableFrame(master = frame_alpha, width = 400, height = 600, corner_radius = 15, fg_color = "#BCAC9B", bg_color = "#242424")
        # this is the scrollable frame for the homepage this will show reccomended things such as watching the lives of the animals through youtube 
        frame_2 = ctk.CTkFrame(master = frame_alpha, width = 180, height = 630, corner_radius = 15, fg_color = "#BCAC9B", bg_color = "#242424")
        # this is the frame for the menu bar this will allow for users to access their settings and accomadation tabs along with a log out feature this will always be on 
            
        # display for ease of access
        frame_alpha.place(relx = 0.5, rely  = 0.5, anchor =tk.CENTER)
        # this places frame alpha onto the homepage ready for use
        frame_1.place(relx = 0.635, rely = 0.5, anchor = tk.CENTER)
        # this places frame 1 onto the homepage ready for use 
        frame_2.place(relx = 0.142, rely = 0.5, anchor = tk.CENTER) 
        # this places frame 2 onto the homepage ready for use 



    class functions:
        class live_animals:
            def live_sloths():
                # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=g_L1Ay8P244")

            def live_pandas():
                # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=3szkFHfr6sA")

            def live_penguins():
                # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=eXfpXKP6qVE")

            def live_giraffes():
            # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=OrAMlVp6yzo")

            def live_gorilla():
                # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=yfSyjwY6zSQ")

            def live_lion():
                # this function will open the website to view the live animals on 
                webbrowser.open_new_tab("https://www.youtube.com/watch?v=pZZst4BOpVI")
        def hotel():
            hp_root.destroy()
            hotel_booking.root_maker()
            


        
    class labels:
        label_1 = ctk.CTkLabel(master = frames.frame_1, text = "watch the live animals!", font = ("arial", 20, "bold"))
        # this creates label one which prompts the user to look at what live animals they have on display via the animal cams
        
    class buttons:
        button_1 = ctk.CTkButton(master = frames.frame_2, height = 75, width = 150, corner_radius = 10, image = images.img_1, text = "settings", fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 14, "bold"))
        # this is the button for the settings page this will allow users to open the settings tabs and set their prefrences
        button_2 = ctk.CTkButton(master = frames.frame_2, height = 75, width = 75, corner_radius = 10, image = images.img_2, text = "hotels", fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 14, "bold"), command= functions.hotel)
        # this is the button for the hotels page this will allow the user to pick hotels/ accomodation that they would like to stay in with the Riget Zoo Adventures or if they want to have a single trip to the zoo
        button_3 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_3, text = "click here to watch the sloths",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_sloths)
        # this is the button to watch the live video of the sloths this will allow the user to open up a web browser and watch the live animals
        button_4 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_4, text = "click here to watch the pandas",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_pandas)
        # this is the button to watch the live video of the pandas this will allow the user to open up a web browser and watch the live animals
        button_5 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_5, text = "click here to watch the penguins",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_penguins)
        # this is the button to watch the live video of the penguins this will allow the user to open up a web browser and watch the live animals
        button_6 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_6, text = "click here to watch the giraffes",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_giraffes)
        # this is the button to watch the live video of the giraffes this will allow the user to open up a web browser and watch the live animals
        button_7 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_7, text = "click here to watch the gorilla",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_gorilla)
        # this is the button to watch the live video of the gorilla this will allow the user to open up a web browser and watch the live animals
        button_8 = ctk.CTkButton(master = frames.frame_1, height = 50, width= 150, corner_radius = 10 , image = images.img_8, text = "click here to watch the lions",fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 16, "bold"), command = functions.live_animals.live_lion)
        # this is the button to watch the live video of the lions this will allow the user to open up a web browser and watch the live animals
        button_9 = ctk.CTkButton(master = frames.frame_2, height = 75, width = 150, corner_radius = 15, image= images.img_9, text = "store", fg_color = "#BCAC9B", hover_color = "#7A6C5D", font = ("arial", 14, "bold"))
        # this is the button to access the store page this will allow for users to purchase any merchandise they have seen within the zoo online,

        labels.label_1.pack(pady = 10)
        # this will place the label onto the scrollable frame to see what animals they would like to pick
        button_1.place(relx = 0.5, rely = 0.15, anchor = tk.CENTER)
        # this will place the button for the settings on the sidebar 
        button_2.place(relx = 0.45, rely = 0.3, anchor = tk.CENTER) 
        # this will place the button for hotels on the sidebar
        button_3.pack(pady = 25)
        # this will place the button for sloths on the the scroll frame
        button_4.pack(pady = 25)
        # this will place the button for pandas on the the scroll frame
        button_5.pack(pady = 25)
        # this will place the button for penguins on the the scroll frame
        button_6.pack(pady = 25)
        # this will place the button for giraffes on the the scroll frame
        button_7.pack(pady = 25)
        # this will place the button for gorilla on the the scroll frame
        button_8.pack(pady = 25)
        # this will place the button for lions on the the scroll frame
        button_9.place(relx = 0.43, rely =  0.45, anchor=  tk.CENTER)
        # this will place the button for store on the sidebar


    hp_root.mainloop()
    # this will generate everything within the homepage root_maker so that it can be displayed as a gui