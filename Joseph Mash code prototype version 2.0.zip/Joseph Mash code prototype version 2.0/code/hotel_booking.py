import sqlite3
# this will import features to allow for the code to access a database for search features etc
import tkinter as tk 
# this will import the foundation code to build the user interface
import customtkinter as ctk 
# this will import additional features to allow for the user interface to look more modern
from PIL import Image, ImageTk
# this will import a image feature to allow for image assets to be used within the code 
ctk.set_default_color_theme("green")
# this will set the default theme of the app to green this will mean that the default colours for buttons etc will be green
from tkinter import messagebox

    

class hotel_db:
    connection = sqlite3.connect(r"databases\hotel.db") 
    # this will connect to the database where the hotel details are storred
    cur = connection.cursor() 
    # this will allow us to execute commands for the sql database within python
    cur.execute("CREATE TABLE  IF NOT EXISTS login_data (id INTEGER IDENTITY(1, 1), user_name TEXT, password TEXT)") 
    # this creates the table where the hotel data is storred
    cur.execute("INSERT INTO login_data VALUES ('1', 'admin', 'admin1')") 
    # this will insert hotel data into the database allowing for occupacy bools and amount of guests
    connection.commit()




def root_maker():
    global hotel_root
    hotel_root = ctk.CTk()
    # this will form the initial app to which the user will click the hotel booking icon and be able to access their booking features
    hotel_root.geometry("650x650")
    # this will decide the apps geometry i have went with the 650x650 this is because it is a moderate size however is also able to fit on the screen
    hotel_root.title("Riget Zoo Adventures Hotel Page") 
    # this will change the title to display Riget Zoo Adventures
    hotel_root.iconbitmap(r"assets\general assets\inverted rza logo.ico") 
    # this will change the default icon to one the will be inputted via a raw string this is so it can access the file directory
    hotel_root._set_appearance_mode("dark")
    # this will change the default appearance mode to dark this is so the app can match a certain theme however this may have the possibility to be changed within the settings

    class functions:
        the_lodge_booked = False
        oak_cottage = False
        hotel_room = False
        
        def booked():
            messagebox.showerror("room sold", "this accommodation is booked")

        def villa_booked():
            entry_box_1 = entry.Entry_1.get()
            entry_box_2 = entry.Entry_2.get()
            if entry_box_1 == "":
                messagebox.showerror("empty details", "i'm sorry but your first name is empty")
            elif entry_box_2 == "":
                messagebox.showerror("empty details", "i'm sorry but your last name is empty")
            elif entry.Entry_1.get() == entry_box_1.isnumeric() or entry_box_1.isdecimal():
                print("boing")
            elif entry.Entry_2.get() == entry_box_2.isnumeric() or entry_box_2.isdecimal():
                print("boing")
            else:
                functions.the_lodge_booked = True
                if functions.the_lodge_booked == True:
                    f_name = entry.Entry_1.get()
                    l_name = entry.Entry_2.get()
                    buttons.button_2.configure(command =  functions.booked)
                    booking_details = [f_name, l_name, "This accomodation is booked!"]
                    messagebox.showinfo("Accomadation Booked!", booking_details)
        
        def cottage_booked():
            entry_box_1 = entry.Entry_1.get()
            entry_box_2 = entry.Entry_2.get()
            if entry.Entry_1 == "":
                messagebox.showerror("empty details", "i'm sorry but your first name is empty")
            elif entry.Entry_2 == "":
                messagebox.showerror("empty details", "i'm sorry but your last name is empty")
            elif entry.Entry_1.get() == entry_box_1.isnumeric() or entry_box_1.isdecimal():
                print("boing")
            elif entry.Entry_2.get() == entry_box_2.isnumeric() or entry_box_2.isdecimal():
                print("boing")
            else:
                functions.oak_cottage = True
                if functions.oak_cottage == True:
                    f_name = entry.Entry_1.get()
                    l_name = entry.Entry_2.get()
                    buttons.button_4.configure(command =  functions.booked)
                    booking_details = [f_name, l_name, "This accomadation is booked"]
                    messagebox.showinfo("Accomadation Booked!", booking_details)
        
        def hotel_booked():
            entry_box_1 = entry.Entry_1.get()
            entry_box_2 = entry.Entry_2.get()
            if entry.Entry_1 == "":
                messagebox.showerror("empty details", "i'm sorry but your first name is empty")
            elif entry.Entry_2 == "":
                messagebox.showerror("empty details", "i'm sorry but your last name is empty")
            elif entry.Entry_1.get() == entry_box_1.isnumeric() or entry_box_1.isdecimal():
                messagebox.showerror("incorrect details", "i'm sorry but your details are just numbers")
            elif entry.Entry_2.get() == entry_box_2.isnumeric() or entry_box_2.isdecimal():
                messagebox.showerror("incorrect details", "i'm sorry but your details are just numbers")
            else:
                functions.hotel_room = True
                if functions.hotel_room == True:
                    f_name = entry.Entry_1.get()
                    l_name = entry.Entry_2.get()
                    buttons.button_3.configure(command =  functions.booked)
                    booking_details = [f_name, l_name, "This accomadation is booked"]
                    messagebox.showinfo("Accomadation Booked!", booking_details)

        def availibility():
            if functions.the_lodge_booked == True:
                messagebox.showinfo("the lodge availibility", "sorry this is currently booked")
            if functions.the_lodge_booked == False:
                messagebox.showinfo("the lodge availibility", "this room is currently availible")
            if functions.oak_cottage == True:
                messagebox.showinfo("the cottage availibility", "sorry this is currently booked")
            if functions.oak_cottage == False:
                messagebox.showinfo("the cottage availibility", "this is currently availible")
            if functions.hotel_room == True:
                messagebox.showinfo("the hotel availibility", "sorry this is currently booked")
            if functions.hotel_room == False:
                messagebox.showinfo("the hotel availibility", " this is currently availible")
            

    class images:
        img_1 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\expensive villa\expensive villa.jpg"), size=(150,150))
        #
        img_2 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\expensive villa\expensive image 2.jpg"), size=(150,150))
        #
        img_3 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\expensive villa\expensive villa 3.jpg"), size=(150,150))
        #
        img_4 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\expensive villa\expensive villa 4.jpg"), size=(150,150))        
        #
        img_5 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\hotel rooms\hotel rooms.jpg"), size=(150,150))
        #
        img_6 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\hotel rooms\zebra hotel rooms.jpg"), size=(150,150))
        #
        img_7 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\hotel rooms\hotel rooms 3.jpg"), size=(150,150))
        #
        img_8 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\hotel rooms\panda hotel rooms (4).jpg"), size=(150,150))
        #
        img_9 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\villa 1\luxury villa.jpg"), size=(150,150))
        #
        img_10 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\villa 1\luxury villa 2.jpg"), size=(150,150))
        #
        img_11 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\villa 1\luxury villa 3.jpg"), size=(150,150))
        #
        img_12 = ctk.CTkImage(Image.open(r"assets\accomodation rooms\villa 1\luxury villa 4.jpg"), size=(150,150))
    


    class frames:
        frame_alpha = ctk.CTkFrame(master = hotel_root, width=650, height=650, corner_radius= 15, fg_color = "#242424", bg_color = "#242424")
        
        frame_1 = ctk.CTkScrollableFrame(master = frame_alpha, width = 400, height = 600, corner_radius = 15, fg_color = "#BCAC9B", bg_color = "#242424")
        #
        frame_2 = ctk.CTkFrame(master = frame_alpha, width= 180, height = 630, corner_radius = 15, fg_color = "#BCAC9B", bg_color = "#242424")
        #
        frame_alpha.place(relx = 0.5, rely = 0.5, anchor = tk.CENTER)
        #
        frame_1.place(relx = 0.638, rely = 0.5, anchor = tk.CENTER)
        #
        frame_2.place(relx = 0.15, rely = 0.5, anchor = tk.CENTER)
        #
    
    class entry:
        Entry_1 = ctk.CTkEntry(master = frames.frame_1, width= 190, height= 15, placeholder_text="enter your  first name here", corner_radius = 10, fg_color = "#DDC9B4",  border_color="#DDC9B4")
        # entry_1 is the entry box for the users first name this will allow for the hotel to have a name for the booking
        Entry_2 = ctk.CTkEntry(master = frames.frame_1, width = 190, height = 15,placeholder_text="enter your last name here", corner_radius = 10, fg_color = "#DDC9B4", border_color="#DDC9B4")
        # entry_1 is the entry box for the users last name this will allow for the hotel to have a name for the booking
        Entry_1.grid(row = 0, column = 4, sticky = tk.W)
        Entry_2.grid(row = 1, column = 4, sticky = tk.W, pady = 25)
    
    class labels:
        label_1 = ctk.CTkLabel(master = frames.frame_1, width= 190, height= 50, text="choose your stay", font=("arial", 25, "bold"))
        label_1.grid(row = 3, column = 4, sticky = tk.W)

    class buttons:
        button_1 = ctk.CTkButton(master = frames.frame_1, text = "availibility", width = 150, height = 50, corner_radius= 15, fg_color = "#BCAC9B",hover_color = "#7A6C5D", font = ("arial", 18, "bold"), command = functions.availibility)
        button_2 = ctk.CTkButton(master = frames.frame_1, text = "the lodge", width = 150, height = 50, corner_radius= 15, fg_color = "#BCAC9B",hover_color = "#7A6C5D", font = ("arial", 18, "bold"), image= images.img_1, command= functions.villa_booked)
        button_3 = ctk.CTkButton(master = frames.frame_1, text = "hotel room", width = 150, height = 50, corner_radius= 15, fg_color = "#BCAC9B",hover_color = "#7A6C5D", font = ("arial", 18, "bold"), image= images.img_5, command= functions.hotel_booked)
        button_4 = ctk.CTkButton(master = frames.frame_1, text = "oak cottage", width = 150, height = 50, corner_radius= 15, fg_color = "#BCAC9B",hover_color = "#7A6C5D", font = ("arial", 18, "bold"), image= images.img_9, command = functions.cottage_booked)
        button_1.grid(row = 2, column = 4, sticky = tk.W)
        button_2.grid(row = 4, column = 4, sticky = tk.W)
        button_3.grid(row = 5, column = 4, sticky = tk.W)
        button_4.grid(row = 6, column = 4, sticky = tk.W)
    hotel_root.mainloop()
