import tkinter as tk 
# this will import the foundation code to build the user interface
import customtkinter as ctk 
# this will import additional features to allow for the user interface to look more modern
from PIL import Image, ImageTk  
# this will import a image feature to allow for image assets to be used within the code
from tkinter import messagebox
# this will import the messagebox feature from tkinter this will allow me to display information to the user
import sqlite3 
# this will import features to allow for the code to access a database for search features etc
ctk.set_default_color_theme("green")
# this will set the default theme of the app to green this will mean that the default colours for buttons etc will be green
import homepage
# this will import the master file.py so that the functions within this .py file can be used


class databases:
    class login_db:
        connection = sqlite3.connect(r"databases\login.db") 
        # this will connect to the database where the login details are storred
        cur = connection.cursor() 
        # this will allow us to execute commands for the sql database within python
        cur.execute("CREATE TABLE  IF NOT EXISTS login_data (id INTEGER IDENTITY(1, 1), user_name TEXT, password TEXT)") 
        # this creates the table where the login data is storred
        cur.execute("INSERT INTO login_data VALUES ('1', 'admin', 'admin1')") 
        # this will insert admin data into the database allowing for a admin override login for development only
        connection.commit()


class functions:
    def sign_up():
        username_check = Entry_bars.Entry_1.get()
        # this will get the string just entered into the username bar
        password_check = Entry_bars.Entry_2.get()
        # this will get the string just entered into the password bar
        if checkbox.ticked.get() == "on": 
            if username_check == "":
                messagebox.showerror("empty sign up", "empty username")
            elif password_check == "":
                messagebox.showerror("empty sign up", "empty password")
                messagebox.showerror("sign up result", "sign up un-sucessful")
                    
            else:    
                    # this function will allow the user to sign up
                    id = 1
                    # this is the variable for the id
                    id  = id + 1
                    # this section of code is what generate a bigger id string the further it goes on  
                    connection = sqlite3.connect(r"databases\login.db") 
                    # this will allow for the user to connect to the login database
                    cur = connection.cursor() 
                    
                    # this will get a hold of the connection cursor
                    username_sign_up = Entry_bars.Entry_3.get()
                    # this takes the string that has just been entered into the username bar
                    password_sign_up = Entry_bars.Entry_4.get()
                    # this takes the string that has just been entered into the password bar
                    cur.execute("INSERT INTO login_data VALUES (?, ?, ?)", (id ,username_sign_up, password_sign_up))
                    # this executes inserting the values that we have created or just got and entered it into he table storred within the database
                    messagebox.showinfo("successfull sign up")
                    # this tells the user that they're signed up 
                    connection.commit()
                    # this will commit the execution we have just performed
                    
        elif checkbox.ticked.get() == "off":
                # if the checkbox is unticked then the message box will appear advising the user
                messagebox.showerror("unticked box", "You Have not ticked the aggeement box and cannot be signed up/ logged in")
        

    def login_reader():
        # this command check is the user has enterred the correct details to be logged in 
        connection = sqlite3.connect(r"databases\login.db")
        # this will connect the user to the  login database 
        cur = connection.cursor()
        #this will get a hold of the connection cursor
        username_check = Entry_bars.Entry_1.get()
         # this will get the string just entered into the username bar
        password_check = Entry_bars.Entry_2.get()
        # this will get the string just entered into the password bar
        cur.execute('SELECT * FROM login_data WHERE user_name == ? AND password == ?',(username_check, password_check))
        # this will execute selecting the data where the username and password match 
        row = cur.fetchall()
        # this will check if the password and the username are on the same row
 
        if username_check == "":
            # checks if the login username is empty
            messagebox.showerror("empty login", "empty username")
            # shows a messagebox that tells the user that the username is empty
        elif password_check == "" and username_check == "":
            # checks if the username and password are empty 
            messagebox.showerror("empty login", "empty password")
            # shows a messagebox that will tell thhe user the password is empty
            messagebox.showerror("login result", "login un-sucessful")
            # shows a messagebox that tell the user their login was unsuccessfuls
        elif row:
                messagebox.showinfo("login result","login successful")
                # this prints the login successful
                root_generator_lp.root_1.destroy()
                # this destroys the login root
                homepage.root_maker()
                # this opens the new homepage route
                # if true then it will print login successfull and will destroy the original route and open the homepage
        else:
                messagebox.showerror("login result", "login un-sucessful")
                # this prints login unsuccessful
                #   this will show if the password and the username do not match or are not on the same row displaying the print of login un-sucessfull prompting the user to try again

        

  
class root_generator_lp: 
    # this will make the class and set up whatever is written within the class this class will be used to make the root
        root_1 = ctk.CTk() 
        # this will form the initial app to which the user will login and be able to access their homepage
        root_1.geometry("650x650") 
        # this will decide the apps geometry i have went with the 650x650 this is because it is a moderate size however is also able to fit on the screen 
        root_1.title("Riget Zoo Adventures Login / Sign-Up Page!") 
        # this will change the title to display Riget Zoo Adventures
        root_1.iconbitmap(r"assets\general assets\inverted rza logo.ico") 
        # this will change the default icon to one the will be inputted via a raw string this is so it can access the file directory
        root_1._set_appearance_mode("dark")
        # this will change the default appearance mode to dark this is so the app can match a certain theme however this may have the possibility to be changed within the settings
    
    
class frames:
    frame_alpha= ctk.CTkFrame(master = root_generator_lp.root_1, width= 650, height = 650, corner_radius = 15, fg_color="#242424", bg_color="#242424") 
    # this class will be used to hold the frames these will be used to display where the buttons and entries are located such as for a sign up and login page
    frame_1 = ctk.CTkFrame(master = frame_alpha, width= 450, height = 500, corner_radius = 15, fg_color="#7A6C5D", bg_color="#242424") 
    # this will create the base frame this will hold two sub frames one for a sign up feature and one for a login feature
    frame_1A = ctk.CTkFrame(master= frame_1, width= 210, height= 430, corner_radius = 15, fg_color="#BCAC9B", bg_color="#7A6C5D") 
    # this will create sub frame A this will be used as the login frame 
    frame_1B = ctk.CTkFrame(master= frame_1, width= 210, height= 430, corner_radius = 15, fg_color="#BCAC9B",bg_color="#7A6C5D") 
    # this will create sub frame B this will be used as the sign up frame
    frame_alpha.place(relx = 0.5, rely = 0.5, anchor = tk.CENTER)
    frame_1.place(relx = 0.5, rely =0.5, anchor = tk.CENTER) 
    # this will place the base frame ont the app and making it visible to users
    frame_1A.place(relx = 0.25, rely = 0.45, anchor = tk.CENTER) 
    # this will place the sub frame for the sign up page making it visible to users
    frame_1B.place(relx = 0.75, rely = 0.45, anchor = tk.CENTER) 
    # this will place the sub frame for the login page making it visible to users

class checkbox:
    # creates the class for a checkbox
    ticked = tk.StringVar(value= "off")
    # defines the ticked variable as False
    checkbox_1 = ctk.CTkCheckBox(master= frames.frame_1, text="""by checking this box you agree to the app 
storing your user name and password""", fg_color="#7A6C5D", corner_radius=10, variable=ticked, onvalue="on", offvalue="off")
    checkbox_1.place(relx = 0.5, rely = 0.95, anchor = tk.CENTER)


class labels:
    label_1 = ctk.CTkLabel(master= frames.frame_1A, width= 190, height= 50, text="login!", font=("arial", 25, "bold")) 
    # this will create label_1 allowing for the users to differentiate between the login and sign up frames
    label_2 = ctk.CTkLabel(master = frames.frame_1B, width = 190, height = 50, text = "sign-up/register!", font=("arial", 25, "bold"))
    # this will create label_2 allowing for users to see where to sign up
    label_1.place(relx = 0.5, rely = 0.18, anchor = tk.CENTER) 
    # this will place label_1 allowing for the user to see what frame is the login and what frame is the sign up
    label_2.place(relx =0.5, rely = 0.18, anchor = tk.CENTER) 
    # this will place label_2 onto the sign up frame allowing for user to see what is is for what purpose

class Entry_bars:
    Entry_1 = ctk.CTkEntry(master = frames.frame_1A, width= 190, height= 15, placeholder_text="enter your username here", corner_radius = 10, fg_color = "#DDC9B4",  border_color="#DDC9B4")
    # entry_1 is the entry box for the users username this will allow for the username to be checked accross the database 
    Entry_2 = ctk.CTkEntry(master = frames.frame_1A, width = 190, height = 15,placeholder_text="enter your password here", corner_radius = 10, fg_color = "#DDC9B4", border_color="#DDC9B4", show = "*")
    # entry_2 is the entry for the users password this will allow for the password to be checked against the database.
    Entry_3 = ctk.CTkEntry(master = frames.frame_1B, width = 190, height = 15,placeholder_text="enter your username here", corner_radius = 10, fg_color = "#DDC9B4", border_color="#DDC9B4")
    # entry_3 is the entry for the users username this will allow for the user to sign up and login which will be checked by a database
    Entry_4 = ctk.CTkEntry(master = frames.frame_1B, width = 190, height = 15,placeholder_text="enter your password here", corner_radius = 10, fg_color = "#DDC9B4", border_color="#DDC9B4", show = "*")
    # entry_4 is the entry for the users password this will allow for the users account to remain secure whilst signing up



    Entry_1.place(relx = 0.5, rely = 0.28, anchor = tk.CENTER) 
    # this will place entry_1 onto frame_1A this is the sub frame for the login system
    Entry_2.place(relx = 0.5, rely = 0.38, anchor = tk.CENTER) 
    # this will place entry_2 onto frame_1A this is the sub frame for the login system
    Entry_3.place(relx = 0.5, rely = 0.28, anchor = tk.CENTER) 
    # this will place entry_3 onto frame_1B this is the sub frame for siging up
    Entry_4.place(relx = 0.5, rely = 0.38, anchor = tk.CENTER) 
    # this will place entry_4 onto frame_1B this is the sub frame for signing up



class buttons:
    button_1 = ctk.CTkButton(master =  frames.frame_1A, width= 190, height = 50, text = "confirm login", corner_radius = 5, command = functions.login_reader)
    # this button is what will be used for comfirmation that the user can log in this will allow for the user to access the homepage or if the login is incorrect try again
    button_2 = ctk.CTkButton(master= frames.frame_1B, width = 190, height = 50, text = "confirm sign-up", corner_radius = 5, command = functions.sign_up)
    # this button is what will be used for confirmation that the user wants to sign up and join the Riget Zoo Adventures app this will then allow the user to login and use more of the app 
    button_1.place(relx = 0.5, rely = 0.5, anchor = tk.CENTER)
    # this will place the button onto the frame for the login so the user knows which one to press 
    button_2.place(relx = 0.5, rely = 0.5, anchor = tk.CENTER)
    # this will place the button onto the frame for the login so the user knows which one to press





root_generator_lp.root_1.mainloop() 
# this is the homepage roots main loop if features are not within the roots creation e.g. root_1 = ctk.CTk & the mainloop then the feature will not be added 